import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyB-Bh6km2isKXs-Qb4GzK4s5r3qHP5A3sk",
  authDomain: "frp-lms.firebaseapp.com",
  projectId: "frp-lms",
  storageBucket: "frp-lms.firebasestorage.app",
  messagingSenderId: "343217749342",
  appId: "1:343217749342:web:14b4f5549f61d3e97f23cf"
};

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);
const database = getDatabase(app);

export { app, auth, database };
