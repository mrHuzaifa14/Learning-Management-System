import { Button, Paper } from '@mui/material'
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import ClassListTable from './ClassListTable';
import { useNavigate } from 'react-router-dom';

const ClassList = () => {

    const navigate = useNavigate();

    const [data, setData] = useState(null);

    useEffect(() => {
      axios
        .get("http://localhost:3000/classes")
        .then((res) => {
          setData(res.data);
        })
        .catch((error) => {
          console.log(error);
        });
    }, []);

  console.log(data);

  return (
    <>
        <Paper>
            <div style={{ padding: "25px", margin: "40px", paddingBottom: "70px", display: "flex", flexDirection: "column", rowGap: "5px" }} >
                <div style={{ textAlign: "center", fontSize: "20px" }} >
                    <h2>Class List</h2>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }} >
                    <div></div>
                    <div>
                        <Button
                          onClick={() => {
                            navigate("/dashboard/class/classform")
                          }}
                          style={{ width: "80px", backgroundColor: "#1E3A8A", borderRadius: "10px" }}
                          variant='contained'
                        >
                          Add
                        </Button>
                    </div>
                </div>
                <br />
                <div>
                    { data && <ClassListTable classData={data} /> }
                </div>
            </div>
        </Paper>
    </>
  )
}

export default ClassList