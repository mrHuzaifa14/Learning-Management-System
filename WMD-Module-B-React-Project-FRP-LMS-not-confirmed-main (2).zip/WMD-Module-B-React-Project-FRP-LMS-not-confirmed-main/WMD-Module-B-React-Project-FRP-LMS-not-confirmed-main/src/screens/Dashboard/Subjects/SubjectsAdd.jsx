import { Button, TextField, Typography } from '@mui/material'
import React, { useState } from 'react'
import RadioButtonsGroup from '../../../components/GenderRadioButtonsGroup'
import GroupRadioButtonsGroup from '../../../components/GroupRadioButtonsGroup'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { Bounce, toast, Zoom } from 'react-toastify'

const SubjectsAdd = () => {

  const navigate = useNavigate();

  const [subjectDetails, setSubjectDetails] = useState({
    subjectName: "",
    class: "",
    group: "",
  });

  const createSubject = () => {

    if (!subjectDetails.subjectName || !subjectDetails.class || !subjectDetails.group) {
      toast.error("Please fill all the fields.", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: false,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        transition: Bounce,
      });
      return;
    }

    axios
      .post("http://localhost:3000/subjects", subjectDetails)
      .then((res) => {
        toast.success('Subject Created Successfully..', {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: false,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
          transition: Zoom,
        });
        navigate("/dashboard/subjects/subjectslist");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <>
        <div style={{ display: "flex", flexDirection: "column", padding: "25px", margin: "0 auto", paddingBottom: "70px", rowGap: "5px" }} >
          <div style={{ textAlign: "center", fontSize: "20px" }} >
            <h2>Subjects Add</h2>
          </div>
          <div>
            <form style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
              <TextField
                onChange={(e) => {
                  setSubjectDetails({ ...subjectDetails, subjectName: e.target.value });
                }}
                color='success'
                label="Subject Name"
                variant="outlined"
              />
              <TextField
                onChange={(e) => {
                  setSubjectDetails({ ...subjectDetails, class: e.target.value });
                }}
                color='success'
                label="Class"
                variant="outlined"
              />
              <GroupRadioButtonsGroup
                onChange={(e) => {
                  setSubjectDetails({ ...subjectDetails, group: e.target.value });
                }}
              />
              <Button
                onClick={createSubject}
                style={{ backgroundColor: "#1E3A8A" }}
                fullWidth
                variant='contained'
              >
                Add
              </Button>
            </form>
          </div>
        </div>
    </>
  )
}

export default SubjectsAdd;
