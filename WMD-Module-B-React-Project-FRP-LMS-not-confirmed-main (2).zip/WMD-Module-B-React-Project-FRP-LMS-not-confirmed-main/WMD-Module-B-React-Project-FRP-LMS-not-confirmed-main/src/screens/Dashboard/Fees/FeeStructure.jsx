import { Paper, Typography } from '@mui/material'
import React from 'react'

const FeeStructure = () => {
  return (
    <>
        <Paper style={{ backgroundColor: "#f5f5f5" }} >
            <div style={{ padding: "25px", margin: "40px", paddingBottom: "70px", display: "flex", flexDirection: "column", rowGap: "40px" }} >
                <div style={{ textAlign: "center", fontSize: "20px", textDecoration: "underline" }} >
                    <h2>Fees Structure</h2>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", flexDirection: "column", rowGap: "15px" }} >
                    <Paper style={{ width: "100%", padding: "20px", borderRadius: "10px" }} >
                        <div style={{ display: "flex", flexDirection: "column", rowGap: "5px" }} >
                            <div style={{ textAlign: "center" }} >
                                <Typography style={{ fontSize: "20px" }} >Semeter 1</Typography>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                <Typography style={{ fontSize: "20px" }} color="primary">Semeter Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Rs:74,000</Typography>
                                </div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Tuition Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Rs:10,000</Typography>
                                </div>
                            </div>
                        </div>
                    </Paper>
                    <Paper style={{ width: "100%", padding: "20px", borderRadius: "10px" }} >
                        <div style={{ display: "flex", flexDirection: "column", rowGap: "5px" }} >
                            <div style={{ textAlign: "center" }} >
                                <Typography style={{ fontSize: "20px"  }} >Class 2</Typography>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Monthly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Rs:600</Typography>
                                </div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Yearly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Rs:7200</Typography>
                                </div>
                            </div>
                        </div>
                    </Paper>
                    <Paper style={{ width: "100%", padding: "20px", borderRadius: "10px" }} >
                        <div style={{ display: "flex", flexDirection: "column", rowGap: "5px" }} >
                            <div style={{ textAlign: "center" }} >
                                <Typography style={{ fontSize: "20px" }} >Class 3</Typography>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Monthly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Rs:700</Typography>
                                </div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Yearly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Rs:8400</Typography>
                                </div>
                            </div>
                        </div>
                    </Paper>
                    <Paper style={{ width: "100%", padding: "20px", borderRadius: "10px" }} >
                        <div style={{ display: "flex", flexDirection: "column", rowGap: "5px" }} >
                            <div style={{ textAlign: "center" }} >
                                <Typography style={{ fontSize: "20px" }} >Class 4</Typography>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Monthly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Rs800</Typography>
                                </div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Yearly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Rs:9600</Typography>
                                </div>
                            </div>
                        </div>
                    </Paper>
                    <Paper style={{ width: "100%", padding: "20px", borderRadius: "10px" }} >
                        <div style={{ display: "flex", flexDirection: "column", rowGap: "5px" }} >
                            <div style={{ textAlign: "center" }} >
                                <Typography style={{ fontSize: "20px" }} >Class 5</Typography>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Monthly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Rs:900</Typography>
                                </div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Yearly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Rs:10800</Typography>
                                </div>
                            </div>
                        </div>
                    </Paper>
                    <Paper style={{ width: "100%", padding: "20px", borderRadius: "10px" }} >
                        <div style={{ display: "flex", flexDirection: "column", rowGap: "5px" }} >
                            <div style={{ textAlign: "center" }} >
                                <Typography style={{ fontSize: "20px" }} >Class 6</Typography>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Monthly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Rs:1000</Typography>
                                </div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Yearly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Rs:12000</Typography>
                                </div>
                            </div>
                        </div>
                    </Paper>
                    <Paper style={{ width: "100%", padding: "20px", borderRadius: "10px" }} >
                        <div style={{ display: "flex", flexDirection: "column", rowGap: "5px" }} >
                            <div style={{ textAlign: "center" }} >
                                <Typography style={{ fontSize: "20px" }} >Class 7</Typography>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Monthly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Rs:1100</Typography>
                                </div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Yearly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Rs:13200</Typography>
                                </div>
                            </div>
                        </div>
                    </Paper>
                    <Paper style={{ width: "100%", padding: "20px", borderRadius: "10px" }} >
                        <div style={{ display: "flex", flexDirection: "column", rowGap: "5px" }} >
                            <div style={{ textAlign: "center" }} >
                                <Typography style={{ fontSize: "20px" }} >Class 8</Typography>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Monthly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Rs:1200</Typography>
                                </div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Yearly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Rs:14400</Typography>
                                </div>
                            </div>
                        </div>
                    </Paper>
                    <Paper style={{ width: "100%", padding: "20px", borderRadius: "10px" }} >
                        <div style={{ display: "flex", flexDirection: "column", rowGap: "5px" }} >
                            <div style={{ textAlign: "center" }} >
                                <Typography style={{ fontSize: "20px" }} >Class 9</Typography>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Monthly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Rs:1300</Typography>
                                </div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Yearly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Rs:15600</Typography>
                                </div>
                            </div>
                        </div>
                    </Paper>
                    <Paper style={{ width: "100%", padding: "20px", borderRadius: "10px" }} >
                        <div style={{ display: "flex", flexDirection: "column", rowGap: "5px" }} >
                            <div style={{ textAlign: "center" }} >
                                <Typography style={{ fontSize: "20px" }} >Class 10</Typography>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Monthly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} color='primary' >Rs:1400</Typography>
                                </div>
                            </div>
                            <div style={{ display: 'flex', justifyContent: "space-between" }} >
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Yearly Fee:</Typography>
                                </div>
                                <div>
                                    <Typography style={{ fontSize: "20px" }} >Rs:16800</Typography>
                                </div>
                            </div>
                        </div>
                    </Paper>
                </div>
                <div></div>
            </div>
        </Paper>
    </>
  )
}

export default FeeStructure