import { Button, FormControl, MenuItem, Paper, TextField, Typography, Divider, Box } from '@mui/material';
import React from 'react';

const FeeVoucher = () => {

    const paymentMethods = [
        { value: 'creditCard', label: 'Credit Card' },
        { value: 'debitCard', label: 'Debit Card' },
        { value: 'netBanking', label: 'Net Banking' },
        { value: 'upi', label: 'UPI' },
        { value: 'cash', label: 'Cash (In-Person)' },
    ];

    return (
        <Paper elevation={4} style={{ width: '70%', margin: '30px auto', padding: '30px', borderRadius: '15px', backgroundColor: '#f3f4f6' }}>
            <Box textAlign="center" mb={4}>
                <Typography variant="h4" fontWeight="bold" color="primary">University Fee Voucher</Typography>
                <Typography variant="subtitle1" color="textSecondary">Academic Year 2025-2026</Typography>
            </Box>

            <Divider sx={{ marginY: 2 }} />

            <Box display="flex" flexDirection="column" gap={3}>
                <FormControl>
                    <TextField
                        label="Full Name *"
                        variant="outlined"
                        color="1E3A8A"
                        fullWidth
                        required
                    />
                </FormControl>

                <FormControl>
                    <TextField
                        label="Student ID *"
                        variant="outlined"
                        color="1E3A8A"
                        fullWidth
                        required
                    />
                </FormControl>

                <FormControl>
                    <TextField
                        label="Class/Program"
                        variant="outlined"
                        fullWidth
                        disabled
                        defaultValue="Bachelor of Science in Computer Science"
                    />
                </FormControl>

                <FormControl>
                    <TextField
                        label="Fee Amount (PKR)"
                        variant="outlined"
                        fullWidth
                        disabled
                        defaultValue="Rs. 74,000"
                    />
                </FormControl>

                <FormControl>
                    <TextField
                        label="Payment Method *"
                        select
                        color="success"
                        fullWidth
                        required
                    >
                        {paymentMethods.map((option) => (
                            <MenuItem key={option.value} value={option.value}>
                                {option.label}
                            </MenuItem>
                        ))}
                    </TextField>
                </FormControl>
            </Box>

            <Box marginTop={4}>
                <Button
                    variant="contained"
                    color="#1E3A8A"
                    fullWidth
                    size="large"
                    style={{ borderRadius: '10px' }}
                >
                    Generate Fee Voucher
                </Button>
            </Box>

            <Box marginTop={3} textAlign="center">
                <Typography variant="caption" color="textSecondary">
                    Please ensure that the payment is made before the due date. Late payments may incur additional charges.
                </Typography>
            </Box>
        </Paper>
    );
}

export default FeeVoucher;
