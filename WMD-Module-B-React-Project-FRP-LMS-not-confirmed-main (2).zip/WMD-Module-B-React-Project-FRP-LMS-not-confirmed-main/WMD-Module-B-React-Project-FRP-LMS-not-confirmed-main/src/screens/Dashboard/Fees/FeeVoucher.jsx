import { Button, Paper, Typography, Divider } from '@mui/material';
import React from 'react';
import { useNavigate } from 'react-router-dom';

const UniversityFeeVoucher = () => {
    const navigate = useNavigate();

    const programs = [
        { name: 'Bachelor of Science in Computer Science', tuition: 150000, semester: 75000, lab: 10000, admission: 20000 },
        { name: 'Bachelor of Business Administration', tuition: 140000, semester: 70000, lab: 5000, admission: 20000 },
        { name: 'Bachelor of Electrical Engineering', tuition: 160000, semester: 80000, lab: 15000, admission: 25000 },
        { name: 'Master of Computer Science', tuition: 180000, semester: 90000, lab: 12000, admission: 30000 },
        { name: 'PhD in Computer Science', tuition: 200000, semester: 100000, lab: 15000, admission: 40000 }
    ];

    return (
        <Paper style={{ backgroundColor: '#E5E7EB', padding: '30px', margin: '40px', borderRadius: '15px' }}>
            <Typography variant="h4" align="center" gutterBottom style={{ textDecoration: 'underline', color: '#1E3A8A', marginBottom: '30px' }}>
                University Fee Vouchers
            </Typography>

            {programs.map((program, index) => (
                <Paper key={index} style={{ margin: '20px 0', padding: '20px', borderRadius: '10px', backgroundColor: '#FFFFFF' }}>
                    <Typography variant="h6" align="center" style={{ color: '#1E3A8A', marginBottom: '15px' }}>
                        Fee Voucher - {program.name}
                    </Typography>
                    <Divider style={{ margin: '10px 0' }} />
                    <div style={{ display: 'flex', flexDirection: 'column', rowGap: '10px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <Typography style={{ fontSize: '18px' }}>Tuition Fee (Per Year):</Typography>
                            <Typography style={{ fontSize: '18px', fontWeight: 'bold', color: '#1E3A8A' }}>Rs {program.tuition}</Typography>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <Typography style={{ fontSize: '18px' }}>Semester Fee (Per Semester):</Typography>
                            <Typography style={{ fontSize: '18px', fontWeight: 'bold', color: '#1E3A8A' }}>Rs {program.semester}</Typography>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <Typography style={{ fontSize: '18px' }}>Lab Charges (Per Year):</Typography>
                            <Typography style={{ fontSize: '18px', fontWeight: 'bold', color: '#1E3A8A' }}>Rs {program.lab}</Typography>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <Typography style={{ fontSize: '18px' }}>Admission Fee (One-Time):</Typography>
                            <Typography style={{ fontSize: '18px', fontWeight: 'bold', color: '#1E3A8A' }}>Rs {program.admission}</Typography>
                        </div>
                    </div>
                    <div style={{ textAlign: 'center', marginTop: '15px' }}>
                        <Button
                            onClick={() => { navigate("/dashboard/fee/feesubmission") }}
                            variant="contained"
                            style={{ backgroundColor: '#1E3A8A', color: '#FFFFFF' }}
                        >
                            Pay Now
                        </Button>
                    </div>
                </Paper>
            ))}

            <Typography variant="body2" align="center" style={{ marginTop: '20px', color: '#374151' }}>
                *All fees are subject to change based on university policies and government regulations.
            </Typography>
        </Paper>
    );
}

export default UniversityFeeVoucher;