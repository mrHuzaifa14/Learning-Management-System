import { Button, TextField } from '@mui/material';
import React, { useState } from 'react';
import GenderRadioButtonsGroup from '../../../components/GenderRadioButtonsGroup';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Bounce, toast, Zoom } from 'react-toastify';

const StudentRegistration = () => {

  const navigate = useNavigate();

  const [stdDetails, setStdDetails] = useState({
    firstName: "",
    lastName: "",
    email: "",
    class: "",
  });

  const createStd = () => {

    if (!stdDetails.firstName || !stdDetails.lastName || !stdDetails.email || !stdDetails.class) {
      toast.error("Please fill all the fields.", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: false,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        transition: Bounce,
      });
      return;
    }

    axios
      .post("http://localhost:3000/students", stdDetails)
      .then((res) => {
        toast.success('User Created Successfully..', {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: false,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
          transition: Zoom,
        });
        navigate("/dashboard/students/studentslist");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <>
        <div style={{ display: "flex", flexDirection: "column", padding: "25px", margin: "0 auto", paddingBottom: "70px", rowGap: "5px" }} >
          <div style={{ textAlign: "center", fontSize: "20px", color: "#1E3A8A" }} >
            <h2>Student Registration</h2>
          </div>
          <div>
            <form style={{ display: "flex", flexDirection: "column", rowGap: "15px" }} >
              <TextField
                onChange={(e) => {
                  setStdDetails({ ...stdDetails, firstName: e.target.value });
                }}
                color='primary'
                label="First Name"
                variant="outlined"
              />
              <TextField
                onChange={(e) => {
                  setStdDetails({ ...stdDetails, lastName: e.target.value });
                }}
                color='primary'
                label="Last Name"
                variant="outlined"
              />
              <TextField
                onChange={(e) => {
                  setStdDetails({ ...stdDetails, email: e.target.value });
                }}
                color='primary'
                label="Email"
                variant="outlined"
              />
              <TextField
                onChange={(e) => {
                  setStdDetails({ ...stdDetails, class: e.target.value });
                }}
                color='primary'
                label="Class"
                variant="outlined"
              />
              <GenderRadioButtonsGroup />
              <Button
  onClick={createStd}
  style={{ backgroundColor: "#1E3A8A", width: "150px", margin: "0" }}
  variant='contained'
>
  Submit
</Button>
            </form>
          </div>
        </div>
    </>
  )
}

export default StudentRegistration;