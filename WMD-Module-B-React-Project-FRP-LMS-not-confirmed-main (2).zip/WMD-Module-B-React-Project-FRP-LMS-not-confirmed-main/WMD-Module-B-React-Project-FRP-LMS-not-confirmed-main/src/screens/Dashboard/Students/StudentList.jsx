import { Button, Paper } from '@mui/material'
import React, { useEffect, useState } from 'react'
import StudentsListTable from './StudentsListTable'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const StudentList = () => {

    const navigate = useNavigate();

    const [data, setData] = useState(null);

    useEffect(() => {
      axios
        .get("http://localhost:3000/students")
        .then((res) => {
          setData(res.data);
        })
        .catch((error) => {
          console.log(error);
        });
    }, []);

  console.log(data);

  return (
    <>
        <Paper>
            <div style={{ padding: "25px", margin: "40px", paddingBottom: "70px", display: "flex", flexDirection: "column", rowGap: "5px", backgroundColor: "#f0f4f8", borderRadius: "12px" }} >
                <div style={{ textAlign: "center", fontSize: "20px", color: "#0d6efd" }} >
                    <h2>Students List</h2>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }} >
                    <div></div>
                    <div>
                        <Button
                          onClick={() => {
                            navigate("/dashboard/students/studentsregistration")
                          }}
                          style={{ width: "100px", backgroundColor: "#0d6efd", borderRadius: "10px", color: "#fff", textTransform: "uppercase", boxShadow: "0 4px 6px rgba(0, 0, 0, 0.2)" }}
                          variant='contained'
                        >
                          Add
                        </Button>
                    </div>
                </div>
                <br />
                <div>
                    { data && < StudentsListTable studentsData={data} /> }
                </div>
            </div>
        </Paper>
    </>
  )
}

export default StudentList
