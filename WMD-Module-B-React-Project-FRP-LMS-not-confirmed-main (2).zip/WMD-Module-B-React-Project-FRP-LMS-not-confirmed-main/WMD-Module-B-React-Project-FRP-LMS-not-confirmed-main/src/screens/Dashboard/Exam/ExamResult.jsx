import { Paper, Typography } from '@mui/material'
import React from 'react'

const ExamResult = () => {

  const classes = [
    {
      class: 1
    },
    {
      class: 2
    },
    {
      class: 3
    },
    {
      class: 4
    },
    {
      class: 5
    },
    {
      class: 6
    },
    {
      class: 7
    },
    {
      class: 8
    },
    {
      class: 9
    },
    {
      class: 10
    },
  ]

  return (
    <>
        <Paper style={{ backgroundColor: "#f5f5f5" }} >
          <div style={{ padding: "25px", margin: "30px 20px", paddingBottom: "70px", display: "flex", flexDirection: "column", rowGap: "40px" }} >
            <div style={{ textAlign: "center", fontSize: "20px", textDecoration: "underline" }} >
              <h2>Exam Result</h2>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", flexDirection: "column", rowGap: "25px", width: "80%", alignSelf: "center" }} >
            {
              classes.map((e, i) => {
                return (
                  <div key={i} style={{ display: "flex", flexDirection: "column", rowGap: "12px" }} >
                    <Typography variant='p' style={{ fontWeight: "bold" }} >Class {e.class} Results</Typography>
                    <Paper style={{ backgroundColor: "#eeeeee" }} >
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-around", padding: "15px" }} >
                        <div>
                          <Typography variant='p' style={{ fontWeight: "bold" }} >Student Name</Typography>
                        </div>
                        <div>
                          <Typography variant='p' style={{ fontWeight: "bold" }} >Roll Number</Typography>
                        </div>
                        <div>
                          <Typography variant='p' style={{ fontWeight: "bold" }} >Grade</Typography>
                        </div>
                      </div>
                    </Paper>
                  </div>
                );
              })
            }
            </div>
          </div>
        </Paper>
    </>
  )
}

export default ExamResult