import { Button, Paper, Typography } from '@mui/material'
import React from 'react'

const ExamSchedule = () => {
  return (
    <>
        <Paper style={{ backgroundColor: "#f5f5f5" }} >
          <div style={{ padding: "25px", margin: "40px", paddingBottom: "70px", display: "flex", flexDirection: "column", rowGap: "40px" }} >
            <div style={{ textAlign: "center", fontSize: "20px", textDecoration: "underline" }} >
              <h2>Exam Schedule</h2>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", flexDirection: "column", rowGap: "15px", width: "80%", alignSelf: "center" }} >
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 1 - Mathematics</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-15</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 09:00 AM | End Time: 12:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 1 - English</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-16</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 10:00 AM | End Time: 01:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 2 - Science</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-17</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 09:30 AM | End Time: 12:30 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 2 - History</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-18</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 11:00 AM | End Time: 02:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 3 - Geography</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-19</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 01:00 PM | End Time: 04:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 3 - Physics</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-20</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 02:00 PM | End Time: 05:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 4 - Chemistry</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-21</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 03:00 PM | End Time: 06:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 5 - Mathematics</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-22</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 09:00 AM | End Time: 12:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 5 - English</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-23</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 10:00 AM | End Time: 01:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 6 - Science</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-24</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 09:30 AM | End Time: 12:50 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 6 - History</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-25</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 11:00 AM | End Time: 02:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 7 - Geography</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-26</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 01:00 PM | End Time: 04:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 7 - Physics</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-27</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 02:00 PM | End Time: 05:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 8 - Chemistry</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-28</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 03:00 PM | End Time: 06:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 9 - Mathematics</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-29</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 09:00 AM | End Time: 12:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 9 - English</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-30</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 10:00 AM | End Time: 01:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 10 - Science</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-08-31</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 09:30 AM | End Time: 12:30 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 10 - History</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-09-01</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 11:00 AM | End Time: 02:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 10 - Geography</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-09-02</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 01:00 PM | End Time: 04:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
              <Paper style={{ padding: "20px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
                  <div>
                    <Typography style={{ fontWeight: "bold" }} >Class 10 - Physics</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Date: 2024-09-03</Typography>
                  </div>
                  <div>
                    <Typography style={{ fontSize: "19px", color: "grey" }} >Start Time: 02:00 PM | End Time: 05:00 PM</Typography>
                  </div>
                  <div>
                    <Button style={{ backgroundColor: "#1E3A8A" }} variant='contained' >View Details</Button>
                  </div>
                </div>
              </Paper>
            </div>
          </div>
        </Paper>
    </>
  )
}

export default ExamSchedule