import { Button, Paper } from '@mui/material'
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import TeahersListTable from './TeachersListTable';
import { useNavigate } from 'react-router-dom';

const TeacherList = () => {

    const navigate = useNavigate();

    const [data, setData] = useState(null);

    useEffect(() => {
        axios
        .get("http://localhost:3000/teachers")
        .then((res) => {
            setData(res.data);
        })
        .catch((error) => {
            console.log(error);
        });
    }, []);

  console.log(data);

  return (
    <>
        <Paper>
            <div style={{ padding: "25px", margin: "40px", paddingBottom: "70px", display: "flex", flexDirection: "column", rowGap: "5px" }} >
                <div style={{ textAlign: "center", fontSize: "20px" }} >
                    <h2>Teachers List</h2>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }} >
                    <div></div>
                    <div>
                        <Button
                            onClick={() => {
                                navigate("/dashboard/teachers/teachersregistration")
                            }}
                            style={{ width: "80px", backgroundColor: "#1E3A8A", borderRadius: "10px" }}
                            variant='contained'
                        >
                            Add
                        </Button>
                    </div>
                </div>
                <br />
                <div>
                    { data && <TeahersListTable teachersData={data} /> }
                </div>
            </div>
        </Paper>
    </>
  )
}

export default TeacherList