import { Button, TextField, Typography, Zoom } from '@mui/material'
import React, { useState } from 'react'
import GenderRadioButtonsGroup from '../../../components/GenderRadioButtonsGroup'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Bounce, toast } from 'react-toastify';

const TeacherRegistration = () => {

  const navigate = useNavigate();

  const [teacherDetails, setTeacherDetails] = useState({
    firstName: "",
    lastName: "",
    email: "",
    class: "",
  });

  const createTeacher = () => {

    if (!teacherDetails.firstName || !teacherDetails.lastName || !teacherDetails.email || !teacherDetails.class) {
      toast.error("Please fill all the fields.", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: false,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        transition: Bounce,
      });
      return;
    }

    axios
      .post("http://localhost:3000/teachers", teacherDetails)
      .then((res) => {
        toast.success('User Created Successfully..', {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: false,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
          transition: Zoom,
        });
        navigate("/dashboard/teachers/teacherslist");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <>
        <div style={{ display: "flex", flexDirection: "column", padding: "25px", margin: "0 auto", paddingBottom: "70px", rowGap: "5px" }} >
          <div style={{ textAlign: "center", fontSize: "20px" }} >
            <h1>Teacher Registration</h1>
          </div>
          <div>
            <form style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
              <TextField
                onChange={(e) => {
                  setTeacherDetails({ ...teacherDetails, firstName: e.target.value });
                }}
                color='success'
                label="First Name"
                variant="outlined"
              />
              <TextField
                onChange={(e) => {
                  setTeacherDetails({ ...teacherDetails, lastName: e.target.value });
                }}
                color='success'
                label="Last Name"
                variant="outlined"
              />
              <TextField
                onChange={(e) => {
                  setTeacherDetails({ ...teacherDetails, email: e.target.value });
                }}
                color='success'
                label="Email"
                variant="outlined"
              />
              <TextField
                onChange={(e) => {
                  setTeacherDetails({ ...teacherDetails, class: e.target.value });
                }}
                color='success'
                label="Class"
                variant="outlined"
              />
              <GenderRadioButtonsGroup />
              <Button
                onClick={createTeacher}
                style={{ backgroundColor: "#1E3A8A" }}
                fullWidth
                variant='contained'
              >
                Submit
              </Button>
            </form>
          </div>
        </div>
    </>
  )
}

export default TeacherRegistration