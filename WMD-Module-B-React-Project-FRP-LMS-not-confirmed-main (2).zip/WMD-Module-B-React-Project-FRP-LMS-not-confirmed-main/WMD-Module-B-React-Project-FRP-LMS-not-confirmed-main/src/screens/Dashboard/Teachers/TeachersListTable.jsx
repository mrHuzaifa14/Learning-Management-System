import * as React from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));

export default function TeahersListTable({ teachersData }) {
  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 300 , maxWidth: 1000 }} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell style={{ backgroundColor: "#008000", fontWeight: "bold" }}>ID</StyledTableCell>
            <StyledTableCell style={{ backgroundColor: "#008000", fontWeight: "bold" }} align="center">First name</StyledTableCell>
            <StyledTableCell style={{ backgroundColor: "#008000", fontWeight: "bold" }} align="center">Last name</StyledTableCell>
            <StyledTableCell style={{ backgroundColor: "#008000", fontWeight: "bold" }} align="center">Email</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {teachersData && teachersData.map((e) => (
            <StyledTableRow key={e.id}>
              <StyledTableCell>{e.id}</StyledTableCell>
              <StyledTableCell align="center">{e.firstName}</StyledTableCell>
              <StyledTableCell align="center">{e.lastName}</StyledTableCell>
              <StyledTableCell align="center">{e.email}</StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
