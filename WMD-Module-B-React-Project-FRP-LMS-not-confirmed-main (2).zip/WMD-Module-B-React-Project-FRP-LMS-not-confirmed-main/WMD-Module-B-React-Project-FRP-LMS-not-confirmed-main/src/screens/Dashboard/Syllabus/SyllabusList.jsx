import { Button, Paper } from '@mui/material'
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import SyllabusListTable from './SyllabusListTable';
import { useNavigate } from 'react-router-dom';

const SyllabusList = () => {

    const navigate = useNavigate();

    const [data, setData] = useState(null);

    useEffect(() => {
        axios
            .get("http://localhost:3000/syllabus")
            .then((res) => {
                setData(res.data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, []);

    console.log(data); 

  return (
    <>
        <Paper>
            <div style={{ padding: "25px", margin: "40px", paddingBottom: "70px", display: "flex", flexDirection: "column", rowGap: "5px" }} >
                <div style={{ textAlign: "center", fontSize: "20px" }} >
                    <h2>Syllabus List</h2>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }} >
                    <div></div>
                    <div>
                        <Button
                            onClick={() => {
                                navigate("/dashboard/syllabus/syllabusform")
                            }}
                            style={{ width: "80px", backgroundColor: "#1E3A8A", borderRadius: "10px" }}
                            variant='contained'
                        >
                            Add
                        </Button>
                    </div>
                </div>
                <br />
                <div>
                    { data && <SyllabusListTable syllabusData={data} /> }
                </div>
            </div>
        </Paper>
    </>
  )
}

export default SyllabusList