import * as React from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Button } from '@mui/material';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));

export default function SyllabusListTable({ syllabusData }) {
  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 300 , maxWidth: 1000 }} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell style={{ backgroundColor: "#008000", fontWeight: "bold" }}>ID</StyledTableCell>
            <StyledTableCell style={{ backgroundColor: "#008000", fontWeight: "bold" }} align="center">Subject Name</StyledTableCell>
            <StyledTableCell style={{ backgroundColor: "#008000", fontWeight: "bold" }} align="center">Class</StyledTableCell>
            <StyledTableCell style={{ backgroundColor: "#008000", fontWeight: "bold" }} align="center">Download</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {syllabusData && syllabusData.map((e) => (
            <StyledTableRow key={e.id}>
              <StyledTableCell>{e.id}</StyledTableCell>
              <StyledTableCell align="center">{e.subjectName}</StyledTableCell>
              <StyledTableCell align="center">{e.class}</StyledTableCell>
              <StyledTableCell align="center"><Button style={{ backgroundColor: "#008000" }} variant='contained' >Download PDF</Button></StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
