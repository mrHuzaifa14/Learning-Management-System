import { Button, TextField } from '@mui/material'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Bounce, toast } from 'react-toastify';

const SyllabusForm = () => {

  const navigate = useNavigate();

  const [syllabusDetails, setSyllabusDetails] = useState({
    subjectName: "",
    class: "",
  });

  const createSyllabus = () => {

    if (!syllabusDetails.subjectName || !syllabusDetails.class) {
      toast.error("Please fill all the fields.", {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: false,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        transition: Bounce,
      });
      return;
    }

    axios
      .post("http://localhost:3000/syllabus", syllabusDetails)
      .then((res) => {
        toast.success('Syllabus Created Successfully..', {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: false,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
          transition: Zoom,
        });
        navigate("/dashboard/syllabus/syllabuslist");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", padding: "25px", margin: "0 auto", paddingBottom: "70px", rowGap: "5px" }} >
      <div style={{ textAlign: "center", fontSize: "20px" }} >
        <h2>Syllabus Add</h2>
      </div>
      <div>
        <form style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
          <TextField
            onChange={(e) => {
              setSyllabusDetails({ ...syllabusDetails, subjectName: e.target.value });
            }}
            color='success'
            label="Subject Name"
            variant="outlined"
            value={syllabusDetails.subjectName}
          />
          <TextField
            onChange={(e) => {
              setSyllabusDetails({ ...syllabusDetails, class: e.target.value });
            }}
            color='success'
            label="Class"
            variant="outlined"
            value={syllabusDetails.class}
          />
          <br />
          <Button
            onClick={createSyllabus}
            style={{ backgroundColor: "#1E3A8A" }}
            fullWidth
            variant='contained'
          >
            Add
          </Button>
        </form>
      </div>
    </div>
  );
}

export default SyllabusForm;
