import { Button, TextField } from '@mui/material';
import axios from 'axios';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { Bounce, toast, Zoom } from 'react-toastify';
import GenderRadioButtonsGroup from '../../../components/GenderRadioButtonsGroup';

const AdmissionForm = () => {
  
  const navigate = useNavigate();

  const [classDetails, setClassDetails] = useState({
    firstName: "",
    lastName: "",
    fatherName: "",
    email: "",
    class: "",
  });

  const createClass = () => {

    if (!classDetails.firstName || !classDetails.lastName || !classDetails.fatherName || !classDetails.email || !classDetails.class) {
        toast.error("Please fill all the fields.", {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: false,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
          transition: Bounce,
        });
      return;
    }

    axios
      .post("http://localhost:3000/classes", classDetails)
      .then((res) => {
        toast.success('Class Created Successfully..', {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: false,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
          transition: Zoom,
        });
        navigate("/dashboard/class/classlist");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <>
        <div style={{ display: "flex", flexDirection: "column", padding: "25px", margin: "0 auto", paddingBottom: "70px", rowGap: "5px" }} >
          <div style={{ textAlign: "center", fontSize: "20px" }} >
            <h2>Admission Form</h2>
          </div>
          <div>
            <form style={{ display: "flex", flexDirection: "column", rowGap: "10px" }} >
              <TextField
                onChange={(e) => {
                  setClassDetails({ ...classDetails, firstName: e.target.value });
                }}
                color='success'
                label="First Name"
                variant="outlined"
              />
              <TextField
                onChange={(e) => {
                  setClassDetails({ ...classDetails, lastName: e.target.value });
                }}
                color='success'
                label="Last Name"
                variant="outlined"
              />
              <TextField
                onChange={(e) => {
                  setClassDetails({ ...classDetails, fatherName: e.target.value });
                }}
                color='success'
                label="Father Name"
                variant="outlined"
              />
              <TextField
                onChange={(e) => {
                  setClassDetails({ ...classDetails, email: e.target.value });
                }}
                color='success'
                label="Email"
                variant="outlined"
              />
              <TextField
                onChange={(e) => {
                  setClassDetails({ ...classDetails, class: e.target.value });
                }}
                color='success'
                label="Class"
                variant="outlined"
              />
              <GenderRadioButtonsGroup />
              <Button
                onClick={createClass}
                style={{ backgroundColor: "#1E3A8A" }}
                fullWidth
                variant='contained'
              >
                Submit
              </Button>
            </form>
          </div>
        </div>
    </>
  )

}

export default AdmissionForm