import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from '../firebaseConfig';
import { Bounce, toast, Zoom } from "react-toastify";
import '../App.css';

const Login = () => {
  const [data, setData] = useState({});
  const navigate = useNavigate();

  const change_handle = (e) => {
    const { value, id } = e.target;
    setData({ ...data, [id]: value });
  };

  const submit_handle = async (e) => {
    e.preventDefault();
    try {
      const userCredential = await signInWithEmailAndPassword(auth, data.email, data.password);
      toast.success('User Login Successfully..', {
        position: "top-center",
        transition: Zoom,
      });
      localStorage.setItem("uid", userCredential.user.uid);
      navigate('/dashboard');
    } catch (error) {
      toast.error(error.message, {
        position: "top-center",
        transition: Bounce,
      });
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Login Form */}
      <div className="w-1/2 flex items-center justify-center bg-white">
        <div className="w-full max-w-md">
          <div className="bg-gray-100 rounded-xl shadow-xl p-8">
            <div className="flex border-b border-gray-300 mb-6">
              <button className="w-1/2 text-center py-2 font-semibold border-b-2 border-blue-700">Login</button>
              <button className="w-1/2 text-center py-2 font-semibold text-gray-500">Register</button>
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-4">Login</h1>
            <form onSubmit={submit_handle} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
                <input
                  type="email"
                  id="email"
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  onChange={change_handle}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input
                  type="password"
                  id="password"
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  onChange={change_handle}
                />
              </div>
              <button
                type="submit"
                className="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-800 transition-all"
              >
                Login
              </button>
              <div className="text-center mt-4">
                <p className="text-gray-600">Don't have an account?{' '}
                  <Link to="/signup" className="text-blue-700 font-semibold">Sign up</Link>
                </p>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* Right Side - Welcome Message */}
      <div className="w-1/2 bg-blue-900 text-white flex items-center justify-center">
        <div className="text-center px-6">
          <h2 className="text-3xl font-bold mb-4">Welcome to EduManager LMS</h2>
          <p className="text-lg">A comprehensive learning management system for modern educational institutions.</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
