import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { ref, set } from "firebase/database";
import { Button, Paper, TextField, Typography } from "@mui/material";
import { auth, database } from "../firebaseConfig";
import { Bounce, toast, Zoom } from "react-toastify";

const Signup = () => {

  const [data, setData] = useState({});

  const navigate = useNavigate();

  const change_handle = (e) => {
    const { value, id } = e.target;
    setData({ ...data, [id]: value });
  };

  const submit_handle = (e) => {
    e.preventDefault();
    createUserWithEmailAndPassword(auth, data.email, data.password)
      .then((userCredential) => {
        const user = userCredential.user;
        console.log('user', user)
        toast.success('User Signup Successfully..', {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
          transition: Zoom,
        });
        set(ref(database, `users/${user.uid}`), {
          name: data.name,
          email: data.email,
          password: data.password,
        });
        navigate("/login")
      })
      .catch((error) => {
        const errorCode = error.code;
        const errorMessage = error.message;
        console.log('errorMessage', errorMessage)
        toast.error('Something went wrong!', {
          position: "top-center",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
          transition: Bounce,
        });
      });
  };

  return (
    <div className="min-h-screen flex">
      <div className="w-1/2 flex items-center justify-center bg-white">
        <Paper
          sx={{
            margin: "0 auto",
            width: { xs: "90%", sm: "80%", md: "60%" },
            marginTop: "65px",
          }}
        >
          <div
            style={{
              padding: "25px",
              paddingBottom: "40px",
              display: "flex",
              flexDirection: "column",
              rowGap: "20px",
            }}
          >
            <div style={{ textAlign: "center", fontSize: "20px" , }}>
              <h1>Sign Up</h1>
            </div>
            <form
              style={{ display: "flex", flexDirection: "column", rowGap: "20px" }}
              onSubmit={submit_handle}
            >
              <TextField
                fullWidth
                type="text"
                id="name"
                label="Full Name"
                variant="outlined"
                required
                onChange={change_handle}
              />
              <TextField
                fullWidth
                type="email"
                id="email"
                label="Email Address"
                variant="outlined"
                required
                onChange={change_handle}
              />
              <TextField
                fullWidth
                type="password"
                id="password"
                label="Password"
                variant="outlined"
                required
                onChange={change_handle}
              />
              <Button
                fullWidth
                style={{ backgroundColor: "var(--color-blue-700);" }}
                variant="contained"
          
                type="submit"
              >
                Sign up
              </Button>
              <div className="flex justify-center items-center mt-4">
                <Typography sx={{ textAlign: "center" }}>
                  Already have an account?
                </Typography>
                <Link to="/login" className="text-blue-700 font-semibold">
                  Login
                </Link>
              </div>
            </form>
          </div>
        </Paper>
      </div>
      <div className="w-1/2 bg-blue-900 text-white flex flex-col items-center justify-center">
        <h2 className="text-4xl font-bold mb-4">Welcome to EduManager LMS</h2>
        <p className="text-lg">A comprehensive learning management system for modern educational institutions.</p>
      </div>
    </div>
  );
};

export default Signup;
