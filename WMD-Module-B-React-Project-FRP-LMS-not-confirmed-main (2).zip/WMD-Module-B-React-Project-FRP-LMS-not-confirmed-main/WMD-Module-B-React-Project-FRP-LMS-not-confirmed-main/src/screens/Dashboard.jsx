import * as React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import AppBar from '@mui/material/AppBar';
import CssBaseline from '@mui/material/CssBaseline';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import InboxIcon from '@mui/icons-material/MoveToInbox';
import SchoolIcon from '@mui/icons-material/School';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import { Route, Routes, Link, useNavigate } from 'react-router-dom';
import { Accordion, AccordionSummary, AccordionDetails, IconButton, Menu, MenuItem, useMediaQuery } from '@mui/material';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import MenuIcon from '@mui/icons-material/Menu';
import StudentRegistration from './Dashboard/Students/StudentRegistration';
import StudentList from './Dashboard/Students/StudentList';
import TeacherRegistration from './Dashboard/Teachers/TeacherRegistration';
import TeacherList from './Dashboard/Teachers/TeacherList';
import SubjectsAdd from './Dashboard/Subjects/SubjectsAdd';
import SubjectsList from './Dashboard/Subjects/SubjectsList';
import SyllabusForm from './Dashboard/Syllabus/SyllabusForm';
import SyllabusList from './Dashboard/Syllabus/SyllabusList';
import ClassForm from './Dashboard/Class/ClassForm';
import ClassList from './Dashboard/Class/ClassList';
import FeeStructure from './Dashboard/Fees/FeeStructure';
import FeeVoucher from './Dashboard/Fees/FeeVoucher';
import FeeSubmission from './Dashboard/Fees/FeeSubmission';
import AdmissionForm from './Dashboard/Admission/AdmissionForm';
import ExamSchedule from './Dashboard/Exam/ExamSchedule';
import ExamResult from './Dashboard/Exam/ExamResult';

const drawerWidth = 240;

export default function Dashboard() {

    const [expanded, setExpanded] = React.useState(null);
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [openDrawer, setOpenDrawer] = React.useState(false);

    const handleAccordionChange = (index) => {
        setExpanded(expanded === index ? null : index);
    };

    const handleMenuClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const navigate = useNavigate();

    const handleMenuClose = () => {
        setAnchorEl(null);
        localStorage.clear();
        navigate("/login");
    };

    const handleDrawerToggle = () => {
        setOpenDrawer(!openDrawer);
    };

    const isMobile = useMediaQuery('(max-width:600px)');

    const pages = [
        {
            name: "Students",
            icon: <InboxIcon />,
            route: "/dashboard/students",
            subPages: [
                { name: "Student Registration", route: "/studentsregistration" },
                { name: "Student List", route: "/studentslist" },
            ]
        },
        {
            name: "Teachers",
            icon: <InboxIcon />,
            route: "/dashboard/teachers",
            subPages: [
                { name: "Teacher Registration", route: "/teachersregistration" },
                { name: "Teacher List", route: "/teacherslist" },
            ]
        },
        {
            name: "Subjects",
            icon: <InboxIcon />,
            route: "/dashboard/subjects",
            subPages: [
                { name: "Subjects Add", route: "/subjectsadd" },
                { name: "Subjects List", route: "/subjectslist" },
            ]
        },
        {
            name: "Syllabus",
            icon: <InboxIcon />,
            route: "/dashboard/syllabus",
            subPages: [
                { name: "Syllabus Form", route: "/syllabusform" },
                { name: "Syllabus List", route: "/syllabuslist" },
            ]
        },
        {
            name: "School",
            icon: <InboxIcon />,
            route: "/dashboard",
            subPages: [
                { name: "Students Registration", route: "/students/studentsregistration" },
                { name: "Teachers Registration", route: "/teachers/teachersregistration" },
            ]
        },
        {
            name: "Class",
            icon: <InboxIcon />,
            route: "/dashboard/class",
            subPages: [
                { name: "Class Form", route: "/classform" },
                { name: "Class List", route: "/classlist" },
            ]
        },
        {
            name: "Fees",
            icon: <InboxIcon />,
            route: "/dashboard",
            subPages: [
                { name: "Fee Structure", route: "/fee/feestructure" },
                { name: "Fee Voucher", route: "/fee/feevoucher" },
                { name: "Fee Submission", route: "/fee/feesubmission" },
            ]
        },
        {
            name: "Admission",
            icon: <InboxIcon />,
            route: "/dashboard/admission",
            subPages: [
                { name: "Admission Form", route: "/admissionform" },
            ]
        },
        {
            name: "Exam",
            icon: <InboxIcon />,
            route: "/dashboard/exam",
            subPages: [
                { name: "Exam Schedule", route: "/examschedule" },
                { name: "Exam Result", route: "/examresult" },
            ]
        }
    ];


    return (
        <Box sx={{ display: 'flex' }}>
            <CssBaseline />
            <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1, backgroundColor: "#1E3A8A" }}>
                <Toolbar>
                    <div style={{ display: "flex", alignItems: 'center', justifyContent: "space-between", width: "100%" }} >
                        <div>
                            <Typography noWrap component="div">
                                <div style={{ display: "flex", alignItems: "center", columnGap: "10px" }} >
                                    <SchoolIcon />
                                    <h4>Learning Management System</h4>
                                </div>
                            </Typography>
                        </div>

                        <div>
                            {isMobile && (
                                <IconButton
                                    edge="end"
                                    color="inherit"
                                    aria-label="menu"
                                    onClick={handleDrawerToggle}
                                    sx={{
                                        borderRadius: '50%',
                                        width: 40,
                                        height: 40,
                                        backgroundColor: '#fff',
                                        color: '#008000',
                                    }}
                                >
                                    <MenuIcon sx={{ fontSize: 30 }} />
                                </IconButton>
                            )}
                            <IconButton
                                edge="end"
                                color="inherit"
                                aria-label="account"
                                onClick={handleMenuClick}
                                sx={{
                                    borderRadius: '50%',
                                    width: 40,
                                    height: 40,
                                    backgroundColor: '#fff',
                                    color: '#008000',
                                }}
                            >
                                <AccountCircleIcon sx={{ fontSize: 20 , color: '#008000' }} />
                            </IconButton>
                            <Menu
                                anchorEl={anchorEl}
                                open={Boolean(anchorEl)}
                                onClose={handleMenuClose}
                            >
                                <MenuItem onClick={handleMenuClose}>Logout</MenuItem>
                            </Menu>
                        </div>
                    </div>
                </Toolbar>
            </AppBar>

            <Drawer
                variant={isMobile ? 'temporary' : 'permanent'}
                open={openDrawer}
                onClose={handleDrawerToggle}
                sx={{
                    width: drawerWidth,
                    flexShrink: 0,
                    [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: 'border-box' },
                }}
            >
                <Toolbar />
                <Box sx={{ overflow: 'auto' }}>
                    <List>
                        {pages.map((obj, index) => (
                            <Accordion
                                key={index}
                                expanded={expanded === index}
                                onChange={() => handleAccordionChange(index)}
                            >
                                <AccordionSummary
                                    expandIcon={expanded === index ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                                    aria-controls={`panel${index}a-content`}
                                    id={`panel${index}a-header`}
                                >
                                    <ListItemButton sx={{ height: "35.7px" }} component={Link} to={obj.route}>
                                        <ListItemIcon sx={{ color: "1E3A8A" }} >{obj.icon}</ListItemIcon>
                                        <ListItemText sx={{ color: "#1E3A8A" }} primary={obj.name} />
                                    </ListItemButton>
                                </AccordionSummary>
                                <AccordionDetails>
                                    <List>
                                        {obj.subPages.map((subPage, subIndex) => (
                                            <ListItem key={subIndex} disablePadding>
                                                <ListItemButton component={Link} to={obj.route + subPage.route}>  {/* Absolute paths */}
                                                    <ListItemText sx={{ color: "#1E3A8A" }} primary={subPage.name} />
                                                </ListItemButton>
                                            </ListItem>
                                        ))}
                                    </List>
                                </AccordionDetails>
                            </Accordion>
                        ))}
                    </List>
                </Box>
            </Drawer>

            <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
                <Typography sx={{ marginBottom: 2, paddingTop: 5 }}>
                    <Routes>
                        <Route path="students/studentsregistration" element={<StudentRegistration />} />
                        <Route path="/" element={<StudentList />}>
                            <Route path="students/studentslist" element={<StudentList />} />
                        </Route>
                        <Route path="teachers/teachersregistration" element={<TeacherRegistration />} />
                        <Route path="teachers/teacherslist" element={<TeacherList />} />
                        <Route path="subjects/subjectsadd" element={<SubjectsAdd />} />
                        <Route path="subjects/subjectslist" element={<SubjectsList />} />
                        <Route path="syllabus/syllabusform" element={<SyllabusForm />} />
                        <Route path="syllabus/syllabuslist" element={<SyllabusList />} />
                        <Route path="class/classform" element={<ClassForm />} />
                        <Route path="class/classlist" element={<ClassList />} />
                        <Route path="fee/feestructure" element={<FeeStructure />} />
                        <Route path="fee/feevoucher" element={<FeeVoucher />} />
                        <Route path="fee/feesubmission" element={<FeeSubmission />} />
                        <Route path="admission/admissionform" element={<AdmissionForm />} />
                        <Route path="exam/examschedule" element={<ExamSchedule />} />
                        <Route path="exam/examresult" element={<ExamResult />} />
                    </Routes>
                </Typography>
            </Box>
        </Box>
    );
}