import * as React from 'react';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';

export default function GroupRadioButtonsGroup({ onChange }) {
  return (
    <FormControl >
      <FormLabel id="demo-radio-buttons-group-label" style={{ color: "#008000" }}>Group</FormLabel>
      <RadioGroup
        onChange={onChange}
        aria-labelledby="demo-radio-buttons-group-label"
        defaultValue="Pre-Engineering"
        name="radio-buttons-group"
      >
        <FormControlLabel 
          value="Pre-Engineering" 
          control={<Radio sx={{ color: "#008000", '&.Mui-checked': { color: '#008000' } }} />} 
          label="Pre-Engineering" 
        />
        <FormControlLabel 
          value="GeneralScience" 
          control={<Radio sx={{ color: "#008000", '&.Mui-checked': { color: '#008000' } }} />} 
          label="GeneralScience" 
        />
      </RadioGroup>
    </FormControl>
  );
}