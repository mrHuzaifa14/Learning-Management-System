import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Login from './screens/Login'
import Signup from './screens/Signup'
import Dashboard from './screens/Dashboard'
import AuthRoute from './components/AuthRoute'
import ProtectedRoute from './components/ProtectedRoute'
import { ToastContainer, Zoom } from 'react-toastify'

function App() {

  return (
    <>
    
      <Routes>

        <Route element={<AuthRoute />} >
          <Route path='/' element={<Login />} >
            <Route path='/login' element={<Login />} />
          </Route>
          <Route path='/signup' element={<Signup />} />
        </Route>
        
        <Route element={<ProtectedRoute />} >
          <Route path='/dashboard/*' element={<Dashboard />} />
        </Route>
      
      </Routes>


      <ToastContainer
        position="top-center"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
        transition={Zoom}
      />

    </>
  )
}

export default App;
