// import { defineConfig } from 'vite'
// import react from '@vitejs/plugin-react'

// // https://vite.dev/config/
// export default defineConfig({
//   plugins: [react()],
// })

import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(),tailwindcss(),],
  build: {
    // Customizing rollupOptions for chunking
    rollupOptions: {
      output: {
        manualChunks: {
          
          // Example for splitting common vendor libraries into separate chunks
          vendor: ['react', 'react-dom'], // Vendor libraries ko alag chunk mein dalenge
        },
      },
    },
    // Adjusting the chunk size warning limit
    chunkSizeWarningLimit: 1000, // 1 MB (default 500 KB)
  },
})